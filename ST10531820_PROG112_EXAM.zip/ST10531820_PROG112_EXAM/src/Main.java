import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
        
        // 1D array for products
        String[] products = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
        // 2D array to hold sales for 3 products over 3 months
        int[][] salesData = new int[3][3];

        // Input loop
        for (int i = 0; i < products.length; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print("Enter number of sales for month " + (j + 1) + " for " + products[i] + " mattress: ");
                salesData[i][j] = scanner.nextInt();
            }
        }

        // Instantiate objects and print
        Product productApp = new Product(salesData);
        PrintProduct printer = new PrintProduct();
        
        printer.printReport(productApp);
        }
    }
}