public class PrintProduct {
    public void printReport(Product product) {
        System.out.println("\nPRODUCT SALES REPORT - 2026");
        System.out.println("*************************************");
        System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
        // Math.round is used to match the screenshot showing '17' instead of '17.0'
        System.out.println("AVERAGE PRODUCT SALES: " + Math.round(product.GetAverageProductSold()));
        System.out.println("MOST POPULAR PRODUCT: " + product.GetMostPopularProduct());
    }
}