public class Product implements IProduct {
    // 1D array for product names
    private final String[] productNames = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
    // 2D array for sales [product index][month index]
    private final int[][] salesData;

    public Product(int[][] salesData) {
        this.salesData = salesData;
    }

    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        // Loop through 2D array to sum all sales
        for (int i = 0; i < salesData.length; i++) {
            for (int j = 0; j < salesData[i].length; j++) {
                total += salesData[i][j];
            }
        }
        return total;
    }

    @Override
    public double GetAverageProductSold() {
        // Total sales divided by the total number of entries (3 products * 3 months = 9)
        int total = GetTotalProductsSold();
        int totalEntries = salesData.length * salesData[0].length;
        return (double) total / totalEntries;
    }

    @Override
    public String GetMostPopularProduct() {
        int maxSales = 0;
        String mostPopular = "";
        int highestSingleSale = 0; // To match the "(25)" in the screenshot, this tracks the highest single month sale for the top product

        for (int i = 0; i < salesData.length; i++) {
            int productTotal = 0;
            for (int j = 0; j < salesData[i].length; j++) {
                productTotal += salesData[i][j];
                if (salesData[i][j] > highestSingleSale) {
                    highestSingleSale = salesData[i][j];
                }
            }
            
            if (productTotal > maxSales) {
                maxSales = productTotal;
                mostPopular = productNames[i];
            }
        }
        // Formatting to match: "Cozy Nights Monarch(25)"
        return mostPopular + "(" + highestSingleSale + ")";
    }

    // Helper method for PrintProduct to get names
    public String[] getProductNames() {
        return productNames;
    }
}