

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ProductTest {

    // Dummy data to test with
    int[][] testData = {
        {25, 18, 20}, // Cozy
        {15, 10, 12}, // Restonic
        {18, 15, 20}  // Sealy
    };

    @Test
    public void GetTotalProductsSold_WithValidData_ReturnsCorrectValue() {
        Product product = new Product(testData);
        // 25+18+20+15+10+12+18+15+20 = 153
        assertEquals(153, product.GetTotalProductsSold());
    }

    @Test
    public void GetAverageSales_WithValidData_ReturnsCorrectValue() {
        Product product = new Product(testData);
        // 153 total / 9 entries = 17.0
        assertEquals(17.0, product.GetAverageProductSold(), 0.0001);
    }
}